﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Klijent
{
    public partial class Form1 : Form
    {
        Komunikacija k; 
        public Form1()
        {
            InitializeComponent();
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
