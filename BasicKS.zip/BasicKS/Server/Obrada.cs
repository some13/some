﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Biblioteka;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using Sesija;

namespace Server
{
    public class Obrada
    {
        private NetworkStream tok;
        BinaryFormatter formater;

        public Obrada(NetworkStream tok)
        {
            // TODO: Complete member initialization
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradi;
            Thread nit = new Thread(ts);
            nit.Start();


        }

        void obradi()
        {
            int operacija = 0;

            //ENUM !!!
            while (operacija != (int)Operacije.Kraj)
            {
                TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                switch (transfer.Operacija)
                {
                    case Operacije.Kraj: operacija = 1;
                        break;
                    default:
                        break;
                }
            }

        }



    }
}
