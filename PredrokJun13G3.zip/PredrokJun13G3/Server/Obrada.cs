﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// DODAJE SE
using Biblioteka;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using Sesija;

namespace Server
{
    public class Obrada
    {
        private NetworkStream tok;
        BinaryFormatter formater;

        public Obrada(NetworkStream tok)
        {
            this.tok = tok;
            formater = new BinaryFormatter();

            ThreadStart ts = obradi;
            Thread nit = new Thread(ts);
            nit.Start();


        }

        void obradi()
        {
            int operacija = 0;

            //ENUM !!!
            while (operacija != (int)Operacije.Kraj)
            {
                TransferKlasa transfer = formater.Deserialize(tok) as TransferKlasa;
                switch (transfer.Operacija)
                {
                        // DODATO KROZ ZADATAK
                        // AKO TREBA DA PROSLEDIMO NESTO U POTPIS KLASE PROSLEDJUJEMO KAO TRANSFER OBJEKAT
                    case Operacije.vratiKurseveZaPolaznike:
                        transfer.TransferObjekat = Broker.dajSesiju().vratiKursZaPolaznika(transfer.TransferObjekat as Polaznik);
                        formater.Serialize(tok, transfer);
                        break;
                        // UKOLIKO SE NE RADI SA LISTAMA KORISTI SE SIGNAL
                    case Operacije.sacuvajKurs:
                        transfer.Signal = Broker.dajSesiju().SacuvajKurs(transfer.TransferObjekat as Kurs);
                        formater.Serialize(tok, transfer);
                        break;
                    case Operacije.vratiJezike:
                        transfer.TransferObjekat = Broker.dajSesiju().vratiJezike();
                        formater.Serialize(tok, transfer);
                        break;
                    case Operacije.vratiPolaznike:
                        transfer.TransferObjekat = Broker.dajSesiju().vratiPolaznike();
                        formater.Serialize(tok, transfer);
                        break;
                     // KRAJ ONOG STO JE DODATO U ZADATAK
                    // POCETNA OPERACIJA KOJA STOJI NA POCETKU ZADATKA
                    case Operacije.Kraj: operacija = 1;
                        break;
                    default:
                        break;
                }
            }

        }



    }
}
