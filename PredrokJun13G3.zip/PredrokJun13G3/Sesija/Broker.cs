﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// OVO SE DODAJE
using Biblioteka;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;

namespace Sesija
{
    public class Broker
    {
        // BASIC DEO
        OleDbCommand komanda;
        OleDbConnection konekcija;
        //! OleDbTransaction transakcija;


        void konektujSe()
        {
            konekcija = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Darko\Downloads\Jun2013-Predrok-G2.accdb");
            komanda = konekcija.CreateCommand();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null)
            {
                instanca = new Broker();
                
            }
            return instanca;
        }

        public Broker()
        {
            konektujSe();
        }

        // KRAJ BASIC DELA

        public List<Jezik> vratiJezike()
        {
            List<Jezik> lista = new List<Jezik>();
            try
            {
                // ***
                konekcija.Open();
                komanda.CommandText = "SELECT * FROM Jezik";
                OleDbDataReader citac = komanda.ExecuteReader();
                // ***
                while (citac.Read())
                {
                    Jezik j = new Jezik();
                    j.JezikID = citac.GetInt32(0);
                    j.Naziv = citac.GetString(1);
                    j.Nivo = citac.GetInt32(2);

                    lista.Add(j);
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<Polaznik> vratiPolaznike()
        {
            List<Polaznik> lista = new List<Polaznik>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "SELECT * FROM Polaznik";
                OleDbDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Polaznik p = new Polaznik();
                    p.PolaznikID = citac.GetInt32(0);
                    p.Jmbg = citac.GetString(1);
                    p.Ime = citac.GetString(2);
                    p.Prezime = citac.GetString(3);

                    lista.Add(p);
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public int vratiSifruKursa()
        {
            int sifra = 0;
            try
            {
                konekcija.Open();
                komanda.CommandText = "SELECT MAX(KursID) FROM Kurs";
                sifra = Convert.ToInt32(komanda.ExecuteScalar());

                return sifra + 1;

            }
            catch (Exception)
            {

                return 1;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public int SacuvajKurs(Kurs k)
        {
            k.KursID = vratiSifruKursa();
            try
            {
                konekcija.Open();
                komanda.CommandText = "Insert into Kurs values("+k.KursID+", "+k.Ocena+", '"+k.DatumPolaganja.ToShortDateString()+"', "+k.Jezik.JezikID+", "+k.Polazink.PolaznikID+")";
                return komanda.ExecuteNonQuery();



            }
            catch (Exception)
            {

                return 0;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        public List<Kurs> vratiKursZaPolaznika(Polaznik p)
        {
            List<Kurs> lista = new List<Kurs>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "SELECT * FROM Jezik INNER JOIN Kurs ON Jezik.[JezikID] = Kurs.[JezikID] WHERE PolaznikID="+p.PolaznikID+" ";
                OleDbDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    Jezik j = new Jezik();
                    j.JezikID = citac.GetInt32(0);
                    j.Naziv = citac.GetString(1);
                    j.Nivo = citac.GetInt32(2);

                    Kurs k = new Kurs();
                    k.KursID = citac.GetInt32(3);
                    k.Ocena = citac.GetInt32(4);
                    k.DatumPolaganja = citac.GetDateTime(5);
                    k.Jezik = j;
                    k.Polazink = p;

                    lista.Add(k);
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }

        public List<KursPrikazServer> vratiKursZaServer()
        {
            List<KursPrikazServer> lista = new List<KursPrikazServer>();
            try
            {
                konekcija.Open();
                komanda.CommandText = "SELECT Jezik.[Naziv], Jezik.[Nivo], COUNT(KursID) FROM Jezik LEFT JOIN Kurs ON Jezik.[JezikID] = Kurs.[JezikID] GROUP BY Jezik.[Naziv], Jezik.[Nivo]";
                OleDbDataReader citac = komanda.ExecuteReader();
                while (citac.Read())
                {
                    KursPrikazServer k = new KursPrikazServer();
                    k.Jezik = citac.GetString(0);
                    k.Nivo = citac.GetInt32(1);
                    k.BrojKandidata = citac.GetInt32(2);
                    lista.Add(k);
                }
                return lista;
            }
            catch (Exception)
            {

                throw;
            }
            finally { if (konekcija != null) konekcija.Close(); }
        }


        // IZ DRUGOG ZADATKA SAMO KAO PRIMER TRANSAKCIJA

        //public int sacuvajLiniju(Linija l)
        //{
        //    l.LinijaID = vratiSifruLinije();
        //    try
        //    {
        //        konekcija.Open();
        //        transakcija = konekcija.BeginTransaction();
        //        string upit = "INSERT INTO Linija VALUES("+l.LinijaID+", '"+l.NazivLinije+"', "+l.Pocetna.StanicaID+", "+l.Krajnja.StanicaID+")";
        //        komanda = new OleDbCommand(upit, konekcija, transakcija);
        //        komanda.ExecuteNonQuery();
        //        foreach (LinijaStanica ls in l.Medjustanice)
        //        {
        //            ls.Linija = l;
        //            sacuvajLinijuStanicu(ls);
        //        }

        //        transakcija.Commit();
        //        return 1;
        //    }
        //    catch (Exception)
        //    {
        //        transakcija.Rollback();
        //        return 0;
        //    }
        //    finally
        //    {
        //        if (konekcija != null)
        //        {
        //            konekcija.Close();
        //        }
        //    }
        //}



        //public int sacuvajLinijuStanicu(LinijaStanica ls)
        //{
        //    try
        //    {
        //        string upit = "INSERT INTO LinijaStanica VALUES(" + ls.Linija.LinijaID + ", " + ls.Stanica.StanicaID + ")";
        //        komanda = new OleDbCommand(upit, konekcija, transakcija);
        //        return komanda.ExecuteNonQuery();
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
         
        //    }
        //}




    }
}
