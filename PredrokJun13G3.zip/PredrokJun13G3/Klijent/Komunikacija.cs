﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// DODATO
using Biblioteka;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;



namespace Klijent
{
    public class Komunikacija
    {
        // POCETAK BASIC DELA
        TcpClient klijent;
        NetworkStream tok;
        BinaryFormatter formater;

        public bool poveziSeNaServer()
        {
            try
            {
                klijent = new TcpClient("127.0.0.1", 10000);
                tok = klijent.GetStream();
                formater = new BinaryFormatter();
                return true;

            }
            catch (Exception)
            {

                return false;
            }
        }


        // KRAJ BASIC DELA


        public List<Jezik> vratiJezike()
        { 
            // slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.vratiJezike;
            formater.Serialize(tok, transfer);

            // prijem

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.TransferObjekat as List<Jezik>;
        }

        public List<Polaznik> vratiPolaznike()
        {
            // slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.vratiPolaznike;
            formater.Serialize(tok, transfer);

            // prijem

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.TransferObjekat as List<Polaznik>;
        }


        public int sacuvajKurs(Kurs k)
        {
            // slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.sacuvajKurs;
            // U SLUCAJU KAD NESTO PROSLEDJUJEMO ONDA TO I OVDE PROSLEDJUJEMO KAO TRANSFER OBJEKAT
            transfer.TransferObjekat = k;
            formater.Serialize(tok, transfer);

            // prijem

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.Signal;
        }


        public List<Kurs> vratiKursZaPolaznike(Polaznik p)
        {
            // slanje
            TransferKlasa transfer = new TransferKlasa();
            transfer.Operacija = Operacije.vratiKurseveZaPolaznike;
            transfer.TransferObjekat = p;
            formater.Serialize(tok, transfer);

            // prijem

            transfer = formater.Deserialize(tok) as TransferKlasa;
            return transfer.TransferObjekat as List<Kurs>;
        }


    }
}
