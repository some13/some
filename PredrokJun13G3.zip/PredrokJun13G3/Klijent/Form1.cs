﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Biblioteka;

namespace Klijent
{
    public partial class Form1 : Form
    {
        // DODAJEMO NA POCETAK KAAKO BI SE POVEZALI NA SEVER
        // BASIC DEO ***
        // ***
        Komunikacija k;
        // ***
        //! Linija l;
        public Form1()
        {
            InitializeComponent();
            // ***
            k = new Komunikacija();
            if (k.poveziSeNaServer())
            {
                this.Text = "Povezan";
            }
            // ***
            //! l = new Linija();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // PUNIMO KOMBO BOKSOVE 
            cmbJezik.DataSource = k.vratiJezike();
            cmbPolaznik.DataSource = k.vratiPolaznike();
            cmbPolaznikFilter.DataSource = k.vratiPolaznike();

            // AKO U DATA GRIDU TREBAMO DA IMAMO KOMBO BOKS OVAKO SE PUNI, PODESAVANJA SE VRSE DESNI KLIK ADD COLON 
            //cmbNMB.DataSource = k.vratiStanice();
            //cmbNMB.ValueMember = "StanicaID";
            //cmbNMB.DisplayMember = "nazivStanice";
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Kurs ku = new Kurs();
            ku.Jezik = cmbJezik.SelectedItem as Jezik;
            ku.Polazink = cmbPolaznik.SelectedItem as Polaznik;
            ku.Ocena = Convert.ToInt32(txtOcena.Text);
            ku.DatumPolaganja = DateTime.ParseExact(txtDatum.Text, "dd.MM.yyyy", null);

            int a = k.sacuvajKurs(ku);
            if (a ==  0)
            {
                MessageBox.Show("Nije sacuvan");
            }
            else
            {
                MessageBox.Show("Sacuvan");
                // osvezavanje tabele
                cmbPolaznikFilter_SelectedIndexChanged(sender, e);
            }
        }

        private void cmbPolaznikFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            Polaznik p = cmbPolaznikFilter.SelectedItem as Polaznik;
            dataGridView1.DataSource = k.vratiKursZaPolaznike(p);

        }
    }
}
