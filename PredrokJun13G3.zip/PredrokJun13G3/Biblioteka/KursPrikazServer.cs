﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    // POMOCNA KLASA KAKO BI SMESTILI ONO STO SE PRIKAZUJE NA SERVER DELU
    [Serializable]
    public class KursPrikazServer
    {
        string jezik;

        public string Jezik
        {
            get { return jezik; }
            set { jezik = value; }
        }
        int nivo;

        public int Nivo
        {
            get { return nivo; }
            set { nivo = value; }
        }
        int brojKandidata;

        public int BrojKandidata
        {
            get { return brojKandidata; }
            set { brojKandidata = value; }
        }
    }
}
