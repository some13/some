﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    // Na pocetku napraviti enum koji ima samo kraj
    // public enum Operacije { Kraj = 1}
    public enum Operacije { Kraj = 1, vratiJezike, vratiPolaznike, sacuvajKurs, vratiKurseveZaPolaznike }

    // klasa mora da bude serijabilna kako bi se prenoslila kroz tok

    // ZA SVAKI ZADATAK ISTO !!!!!!!!!
    [Serializable]
    public class TransferKlasa
    {
        Operacije operacija;

        public Operacije Operacija
        {
            get { return operacija; }
            set { operacija = value; }
        }
        Object transferObjekat;

        public Object TransferObjekat
        {
            get { return transferObjekat; }
            set { transferObjekat = value; }
        }
        int signal;

        public int Signal
        {
            get { return signal; }
            set { signal = value; }
        }
    }
}
