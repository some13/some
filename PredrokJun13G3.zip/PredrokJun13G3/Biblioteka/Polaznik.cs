﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Polaznik
    {
        public override string ToString()
        {
            return ime + " " + prezime;
        }

        int polaznikID;

        public int PolaznikID
        {
            get { return polaznikID; }
            set { polaznikID = value; }
        }
        string jmbg;

        public string Jmbg
        {
            get { return jmbg; }
            set { jmbg = value; }
        }
        string ime;

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        string prezime;

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }
    }
}
