﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Jezik
    {

        public override string ToString()
        {
            return naziv;
        }


        int jezikID;

        public int JezikID
        {
            get { return jezikID; }
            set { jezikID = value; }
        }
        string naziv;

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }
        int nivo;

        public int Nivo
        {
            get { return nivo; }
            set { nivo = value; }
        }

        // PRIMER IZ DRUGOG ZADATKA, BINDING LISTE, KORISTIMO NPR KAD IMAMO DA DODAMO NESTO U LISTU PA KASNIJE SACUVAMO NA SERVER STRANU
        // INICIJALIZACIJA SE VRSI NA KLIJENT FORMI

        //BindingList<LinijaStanica> medjustanice;

        //public BindingList<LinijaStanica> Medjustanice
        //{
        //    get { return medjustanice; }
        //    set { medjustanice = value; }
        //}

        //public Linija()
        //{
        //    medjustanice = new BindingList<LinijaStanica>();
        //}



    }
}
