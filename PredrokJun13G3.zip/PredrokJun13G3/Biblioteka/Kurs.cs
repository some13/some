﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Biblioteka
{
    [Serializable]
    public class Kurs
    {
        int kursID;

        public int KursID
        {
            get { return kursID; }
            set { kursID = value; }
        }
        int ocena;

        public int Ocena
        {
            get { return ocena; }
            set { ocena = value; }
        }
        DateTime datumPolaganja;

        public DateTime DatumPolaganja
        {
            get { return datumPolaganja; }
            set { datumPolaganja = value; }
        }
        Jezik jezik;

        public Jezik Jezik
        {
            get { return jezik; }
            set { jezik = value; }
        }
        Polaznik polazink;

        public Polaznik Polazink
        {
            get { return polazink; }
            set { polazink = value; }
        }


    }
}
