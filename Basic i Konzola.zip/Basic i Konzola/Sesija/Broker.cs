﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// OVO SE DODAJE
using Biblioteka;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;

namespace Sesija
{
    public class Broker
    {
        OleDbCommand komanda;
        OleDbConnection konekcija;


        void konektujSe()
        {
            konekcija = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Darko\Documents\Visual Studio 2010\Projects\Septembar\StudentskaSluzba\Baza.accdb");
            komanda = konekcija.CreateCommand();
        }

        public static Broker instanca;
        public static Broker dajSesiju()
        {
            if (instanca == null)
            {
                instanca = new Broker();
                
            }
            return instanca;
        }

        public Broker()
        {
            konektujSe();
        }

    }
}
