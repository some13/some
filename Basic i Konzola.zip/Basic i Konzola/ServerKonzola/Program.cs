﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServerKonzola
{
    class Program
    {
        static void Main(string[] args)
        {
            Server s = new Server();
            if (s.pokreniServer())
            {
                Console.WriteLine("Pokrenut!");
            }
        }
    }
}
